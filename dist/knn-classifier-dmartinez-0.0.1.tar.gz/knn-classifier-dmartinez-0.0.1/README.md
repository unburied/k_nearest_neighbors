# k_nearest_neighbors
Simple implementation of the KNN Algorithm
